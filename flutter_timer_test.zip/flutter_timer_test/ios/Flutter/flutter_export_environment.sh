#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/sikyungkim/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/sikyungkim/Tium/src/flutter/examples/flutter_timer_test"
export "FLUTTER_TARGET=/Users/sikyungkim/Tium/src/flutter/examples/flutter_timer_test/lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "SYMROOT=${SOURCE_ROOT}/../build/ios"
export "OTHER_LDFLAGS=$(inherited) -framework Flutter"
export "FLUTTER_FRAMEWORK_DIR=/Users/sikyungkim/flutter/bin/cache/artifacts/engine/ios"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "TRACK_WIDGET_CREATION=true"
export "DART_DEFINES=flutter.inspector.structuredErrors=true"
